(() => {
  'use strict';
  if (window.__waInjected) return;
  window.__waInjected = true;

  // ======================== 状态 ========================

  const STATE = {
    active: false,
    tool: 'pen',
    color: '#f44336',
    size: 3,
    strokes: [],
    currentStroke: null,
    drawing: false,
    startX: 0,
    startY: 0,
    selectedStrokeIndex: -1,
    selectDragState: null,
    textSelectable: true,
    erasing: false,
    expanded: false,      // 工具栏是否展开（紧凑/完整）
    autoCompact: true,    // 绘制后自动收起工具栏
  };

  const COLORS = [
    '#f44336', '#ff9800', '#ffeb3b', '#4caf50',
    '#2196f3', '#9c27b0', '#e91e63', '#ffffff', '#000000',
  ];

  const SIZES = [2, 4, 8, 14, 24];

  const FONT_FAMILY = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

  const PREFS_KEY = 'wa_prefs';
  const WELCOME_PENDING_KEY = 'wa_welcome_pending';
  const WELCOME_SEEN_AT_KEY = 'wa_welcome_seen_at';

  // 图标改为 currentColor 跟随 CSS 文字颜色(支持悬停和激活状态的蓝色变色)
  const TOOL_DEFS = [
    {
      id: 'select',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 1L3 12L6.5 8.5L10 14L12 13L8.5 7L13 7L3 1Z" fill="currentColor" stroke="#fff" stroke-width="0.6" stroke-linejoin="round"/></svg>',
      label: '选择移动',
      help: '选中已有标注并拖动位置。',
    },
    {
      id: 'pen',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.5 1.5L14.5 4.5L5 14H2V11L11.5 1.5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M9.5 3.5L12.5 6.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',
      label: '画笔',
      help: '按住拖动，自由书写和圈画。',
    },
    {
      id: 'highlighter',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M10.8 1.5L14.5 5.2L7.5 12.2L3 13L3.8 8.5L10.8 1.5Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><rect x="3" y="8" width="6" height="5" rx="0.5" transform="rotate(-45 3 8)" fill="#f5c542" opacity="0.5"/><path d="M1 15H7" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>',
      label: '荧光笔',
      help: '半透明标记重点内容。',
    },
    {
      id: 'eraser',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M13.3 5.3L10.7 2.7C10.3 2.3 9.7 2.3 9.3 2.7L2.3 9.7C1.9 10.1 1.9 10.7 2.3 11.1L4.2 13H8.6L13.3 8.3C13.7 7.9 13.7 5.7 13.3 5.3Z" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 6L10 9.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M2 13H14" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/><path d="M2.3 9.7L6.5 6L10 9.5L5.8 13" fill="#ff6b6b" opacity="0.45"/></svg>',
      label: '橡皮擦',
      help: '拖过笔迹即可擦除。',
    },
    {
      id: 'rect',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="3" width="12" height="10" rx="1.5" stroke="currentColor" stroke-width="1.4" stroke-dasharray="3 2"/></svg>',
      label: '矩形',
      help: '拖拽框选页面区域。',
    },
    {
      id: 'arrow',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M2 14L12 4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M6 3.5H12.5V10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      label: '箭头',
      help: '拖出箭头指向目标。',
    },
    {
      id: 'text',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 4V3H13V4" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M8 3V13" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M5.5 13H10.5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
      label: '文本框',
      help: '拖出区域并输入文字。',
    },
  ];

  const ACTION_DEFS = [
    {
      className: 'wa-tb-text-select',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="3" y="1.5" width="10" height="13" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M6 1.5V3H10V1.5" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M5.5 6.5H10.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M5.5 9H10.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M5.5 11.5H8.5" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>',
      label: '文本选取开关',
      help: '允许选择和复制文本批注。',
    },
    {
      className: 'wa-tb-undo',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 7L2 5L4 3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M2 5H10C12.2 5 14 6.8 14 9C14 11.2 12.2 13 10 13H6" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
      label: '撤销',
      help: '撤回上一步操作。',
    },
    {
      className: 'wa-tb-redo',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M12 7L14 5L12 3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M14 5H6C3.8 5 2 6.8 2 9C2 11.2 3.8 13 6 13H10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>',
      label: '恢复',
      help: '恢复刚撤销的操作。',
    },
    {
      className: 'wa-tb-clear',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3 4H13" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M6 4V2.5H10V4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M4 4L4.7 13.5H11.3L12 4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"/><path d="M6.5 6.5V11" stroke="currentColor" stroke-width="1" stroke-linecap="round"/><path d="M9.5 6.5V11" stroke="currentColor" stroke-width="1" stroke-linecap="round"/></svg>',
      label: '清除全部',
      help: '删除当前页面所有标注。',
    },
    {
      className: 'wa-tb-export',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 2V10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M5 5L8 2L11 5" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 10V13H13V10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      label: '导出标注',
      help: '导出本机标注数据备份。',
    },
    {
      className: 'wa-tb-import',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8 10V2" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/><path d="M5 7L8 10L11 7" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M3 10V13H13V10" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      label: '导入标注',
      help: '导入备份恢复以往标注。',
    },
    {
      className: 'wa-tb-close',
      icon: '<svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M3.5 8.5L7 12L13.5 4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
      label: '完成标注',
      help: '收起工具，保留页面标注显示。',
    },
  ];

  function savePrefs() {
    chrome.storage.local.set({ [PREFS_KEY]: { tool: STATE.tool, color: STATE.color, size: STATE.size, textSelectable: STATE.textSelectable, autoCompact: STATE.autoCompact } });
  }

  function loadPrefs() {
    return new Promise(resolve => {
      chrome.storage.local.get(PREFS_KEY, d => {
        const prefs = d[PREFS_KEY] || null;
        if (prefs) {
          if (prefs.tool) STATE.tool = prefs.tool;
          if (prefs.color) STATE.color = prefs.color;
          if (prefs.size) STATE.size = prefs.size;
          if (typeof prefs.textSelectable === 'boolean') STATE.textSelectable = prefs.textSelectable;
          if (typeof prefs.autoCompact === 'boolean') STATE.autoCompact = prefs.autoCompact;
        }
        resolve(prefs || null);
      });
    });
  }

  function shouldShowWelcome() {
    return new Promise(resolve => {
      try {
        chrome.storage.local.get(WELCOME_PENDING_KEY, d => resolve(d[WELCOME_PENDING_KEY] === true));
      } catch {
        resolve(false);
      }
    });
  }

  function markWelcomeSeen() {
    try {
      chrome.storage.local.set({
        [WELCOME_PENDING_KEY]: false,
        [WELCOME_SEEN_AT_KEY]: Date.now(),
      });
    } catch {}
  }

  // 自动检测到的滚动容器（可能是 window，也可能是某个内部 div）
  let scrollEl = null;

  // 撤销恢复栈
  const undoHistory = [];
  const redoHistory = [];

  // ======================== 存储 ========================

  function pageKey() {
    return 'wa_draw_' + location.origin + location.pathname;
  }

  function loadStrokes() {
    return new Promise(resolve => {
      try {
        const local = localStorage.getItem(pageKey());
        if (local) {
          const parsed = JSON.parse(local);
          if (Array.isArray(parsed) && parsed.length > 0) {
            resolve(parsed);
            return;
          }
        }
      } catch {}

      try {
        chrome.storage.local.get(pageKey(), d => {
          const data = d[pageKey()] || [];
          if (data.length > 0) {
            try { localStorage.setItem(pageKey(), JSON.stringify(data)); } catch {}
          }
          resolve(data);
        });
      } catch {
        resolve([]);
      }
    });
  }

  function saveStrokes() {
    try {
      localStorage.setItem(pageKey(), JSON.stringify(STATE.strokes));
    } catch {}
    try {
      chrome.storage.local.set({ [pageKey()]: STATE.strokes });
    } catch {}
  }

  // ======================== 滚动容器探测 ========================

  function getScroll() {
    if (scrollEl && scrollEl !== document && scrollEl !== document.documentElement) {
      return { x: scrollEl.scrollLeft, y: scrollEl.scrollTop };
    }
    return { x: window.scrollX, y: window.scrollY };
  }

  // ======================== DOM 锚定 ========================

  function getElementPath(el) {
    const parts = [];
    let node = el;
    while (node && node.parentElement) {
      const siblings = node.parentElement.children;
      for (let i = 0; i < siblings.length; i++) {
        if (siblings[i] === node) { parts.unshift(i); break; }
      }
      node = node.parentElement;
    }
    return parts.join('/');
  }

  function findElementByPath(path) {
    if (!path) return null;
    try {
      const indices = path.split('/').map(Number);
      let el = document.documentElement;
      for (const idx of indices) {
        if (!el.children || idx >= el.children.length) return null;
        el = el.children[idx];
      }
      return el;
    } catch { return null; }
  }

  function getRangeRect(textNode, offset) {
    const len = textNode.textContent.length;
    const start = Math.min(offset, len);
    const end = start < len ? start + 1 : Math.max(start - 1, 0);
    const range = document.createRange();
    range.setStart(textNode, Math.min(start, end));
    range.setEnd(textNode, Math.max(start, end));
    const rect = range.getBoundingClientRect();
    if (rect.width === 0 && rect.height === 0 && rect.left === 0 && rect.top === 0) return null;
    return rect;
  }

  function tryCaretAnchor(docX, docY) {
    if (!document.caretRangeFromPoint) return null;
    const scroll = getScroll();
    const clientX = docX - scroll.x;
    const clientY = docY - scroll.y;
    if (clientX < 0 || clientX >= window.innerWidth || clientY < 0 || clientY >= window.innerHeight) return null;

    displayCanvas.style.visibility = 'hidden';
    drawCanvas.style.visibility = 'hidden';
    toolbar.style.visibility = 'hidden';
    const caretRange = document.caretRangeFromPoint(clientX, clientY);
    displayCanvas.style.visibility = '';
    drawCanvas.style.visibility = '';
    toolbar.style.visibility = '';

    if (!caretRange || caretRange.startContainer.nodeType !== Node.TEXT_NODE) return null;

    const textNode = caretRange.startContainer;
    const offset = caretRange.startOffset;
    const parentEl = textNode.parentElement;
    if (!parentEl || parentEl === document.body || parentEl === document.documentElement) return null;
    if (parentEl.closest && parentEl.closest('#wa-toolbar, .wa-text-input')) return null;

    let childIndex = -1;
    for (let i = 0; i < parentEl.childNodes.length; i++) {
      if (parentEl.childNodes[i] === textNode) { childIndex = i; break; }
    }
    if (childIndex === -1) return null;

    const rect = getRangeRect(textNode, offset);
    if (!rect) return null;

    return {
      parentPath: getElementPath(parentEl),
      childIndex,
      charOffset: offset,
      rx: rect.left + scroll.x,
      ry: rect.top + scroll.y,
    };
  }

  function tryElementAnchor(docX, docY) {
    const scroll = getScroll();
    const cx = docX - scroll.x;
    const cy = docY - scroll.y;
    if (cx < 0 || cx >= window.innerWidth || cy < 0 || cy >= window.innerHeight) return null;

    let el = null;
    for (const candidate of document.elementsFromPoint(cx, cy)) {
      if (candidate === displayCanvas || candidate === drawCanvas || candidate === toolbar) continue;
      if (candidate.id && candidate.id.startsWith('wa-')) continue;
      if (candidate.closest && candidate.closest('#wa-toolbar, .wa-text-input')) continue;
      if (candidate === document.documentElement || candidate === document.body) continue;
      el = candidate;
      break;
    }
    if (!el) return null;

    const rect = el.getBoundingClientRect();
    const elX = rect.left + scroll.x;
    const elY = rect.top + scroll.y;
    return {
      path: getElementPath(el),
      ox: elX,
      oy: elY,
      ow: rect.width,
      oh: rect.height,
      fx: rect.width > 0 ? (docX - elX) / rect.width : 0,
      fy: rect.height > 0 ? (docY - elY) / rect.height : 0,
    };
  }

  function computeAnchor(stroke) {
    const pts = stroke.points;
    if (!pts || pts.length === 0) return null;
    let cx = 0, cy = 0;
    for (const p of pts) { cx += p.x; cy += p.y; }
    cx /= pts.length;
    cy /= pts.length;

    return tryCaretAnchor(cx, cy) || tryElementAnchor(cx, cy);
  }

  function getAnchorShift(stroke) {
    const a = stroke.anchor;
    if (!a) return null;

    if (a.parentPath) {
      const parentEl = findElementByPath(a.parentPath);
      if (!parentEl) return null;
      const node = parentEl.childNodes[a.childIndex];
      if (!node || node.nodeType !== Node.TEXT_NODE) return null;
      const rect = getRangeRect(node, a.charOffset);
      if (!rect) return null;
      const scroll = getScroll();
      return { dx: rect.left + scroll.x - a.rx, dy: rect.top + scroll.y - a.ry };
    }

    if (a.path) {
      const el = findElementByPath(a.path);
      if (!el) return null;
      const scroll = getScroll();
      const rect = el.getBoundingClientRect();
      const origCX = a.ox + (a.fx || 0) * (a.ow || 0);
      const origCY = a.oy + (a.fy || 0) * (a.oh || 0);
      const newCX = rect.left + scroll.x + (a.fx || 0) * rect.width;
      const newCY = rect.top + scroll.y + (a.fy || 0) * rect.height;
      return { dx: newCX - origCX, dy: newCY - origCY };
    }

    return null;
  }

  // ======================== 选择模式：碰撞检测与拖动 ========================

  function distToSegment(px, py, x1, y1, x2, y2) {
    const dx = x2 - x1;
    const dy = y2 - y1;
    const lenSq = dx * dx + dy * dy;
    if (lenSq === 0) return Math.hypot(px - x1, py - y1);
    let t = ((px - x1) * dx + (py - y1) * dy) / lenSq;
    t = Math.max(0, Math.min(1, t));
    return Math.hypot(px - (x1 + t * dx), py - (y1 + t * dy));
  }

  function hitTestStroke(stroke, docX, docY, customThreshold) {
    if (!stroke.points || stroke.points.length === 0) return false;

    const shift = getAnchorShift(stroke);
    const tx = docX - (shift ? shift.dx : 0);
    const ty = docY - (shift ? shift.dy : 0);
    const pts = stroke.points;
    const threshold = customThreshold !== undefined ? customThreshold : Math.max(10, stroke.size * 1.5);

    if (stroke.tool === 'text') {
      if (pts.length < 2) return false;
      const x0 = Math.min(pts[0].x, pts[1].x);
      const y0 = Math.min(pts[0].y, pts[1].y);
      const x1 = Math.max(pts[0].x, pts[1].x);
      const y1 = Math.max(pts[0].y, pts[1].y);
      return tx >= x0 && tx <= x1 && ty >= y0 && ty <= y1;
    }

    if (stroke.tool === 'rect') {
      if (pts.length < 2) return false;
      const x0 = Math.min(pts[0].x, pts[1].x);
      const y0 = Math.min(pts[0].y, pts[1].y);
      const x1 = Math.max(pts[0].x, pts[1].x);
      const y1 = Math.max(pts[0].y, pts[1].y);
      if (tx < x0 - threshold || tx > x1 + threshold || ty < y0 - threshold || ty > y1 + threshold) return false;
      return Math.abs(tx - x0) < threshold || Math.abs(tx - x1) < threshold ||
             Math.abs(ty - y0) < threshold || Math.abs(ty - y1) < threshold;
    }

    if (stroke.tool === 'arrow') {
      if (pts.length < 2) return false;
      const last = pts[pts.length - 1];
      return distToSegment(tx, ty, pts[0].x, pts[0].y, last.x, last.y) < threshold;
    }

    if (pts.length === 1) {
      return Math.hypot(tx - pts[0].x, ty - pts[0].y) < threshold;
    }
    for (let i = 0; i < pts.length - 1; i++) {
      if (distToSegment(tx, ty, pts[i].x, pts[i].y, pts[i + 1].x, pts[i + 1].y) < threshold) {
        return true;
      }
    }
    return false;
  }

  function findStrokeAt(docX, docY) {
    for (let i = STATE.strokes.length - 1; i >= 0; i--) {
      if (hitTestStroke(STATE.strokes[i], docX, docY)) return i;
    }
    return -1;
  }

  function updateEraserCursor(clientX, clientY) {
    const diameter = Math.max(STATE.size * 4, 20);
    eraserCursor.style.width = diameter + 'px';
    eraserCursor.style.height = diameter + 'px';
    eraserCursor.style.left = clientX + 'px';
    eraserCursor.style.top = clientY + 'px';
  }

  let eraserSnapshot = null;
  let eraserDirty = false;

  function eraseAtPoint(docX, docY) {
    const eraserRadius = Math.max(STATE.size * 2, 10);
    let changed = false;

    for (let i = STATE.strokes.length - 1; i >= 0; i--) {
      const stroke = STATE.strokes[i];

      if (stroke.tool === 'text' || stroke.tool === 'rect' || stroke.tool === 'arrow' || stroke.tool === 'eraser') {
        if (hitTestStroke(stroke, docX, docY, eraserRadius)) {
          STATE.strokes.splice(i, 1);
          changed = true;
        }
        continue;
      }

      if (!stroke.points || stroke.points.length === 0) continue;

      const shift = getAnchorShift(stroke);
      const sdx = shift ? shift.dx : 0;
      const sdy = shift ? shift.dy : 0;

      const segments = [];
      let seg = [];

      for (let j = 0; j < stroke.points.length; j++) {
        const px = stroke.points[j].x + sdx;
        const py = stroke.points[j].y + sdy;

        if (Math.hypot(px - docX, py - docY) <= eraserRadius) {
          if (seg.length > 0) { segments.push(seg); seg = []; }
        } else {
          if (j > 0 && seg.length > 0) {
            const prev = seg[seg.length - 1];
            if (distToSegment(docX, docY, prev.x + sdx, prev.y + sdy, px, py) <= eraserRadius) {
              segments.push(seg);
              seg = [];
            }
          }
          seg.push(stroke.points[j]);
        }
      }
      if (seg.length > 0) segments.push(seg);

      if (segments.length === 1 && segments[0].length === stroke.points.length) continue;

      STATE.strokes.splice(i, 1);
      for (let s = segments.length - 1; s >= 0; s--) {
        if (segments[s].length < 1) continue;
        const newPoints = segments[s].map(p => ({ x: p.x + sdx, y: p.y + sdy }));
        const ns = { tool: stroke.tool, color: stroke.color, size: stroke.size, points: newPoints, text: '', anchor: null };
        ns.anchor = computeAnchor(ns);
        STATE.strokes.splice(i, 0, ns);
      }
      changed = true;
    }

    if (changed) {
      eraserDirty = true;
      STATE.selectedStrokeIndex = -1;
      redrawDisplay();
      syncTextOverlays();
    }
  }

  function drawSelectionBox(ctx, stroke, scroll) {
    if (!stroke.points || stroke.points.length === 0) return;

    const shift = getAnchorShift(stroke);
    const ox = (shift ? shift.dx : 0) - scroll.x;
    const oy = (shift ? shift.dy : 0) - scroll.y;

    let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
    for (const p of stroke.points) {
      const px = p.x + ox, py = p.y + oy;
      if (px < minX) minX = px;
      if (py < minY) minY = py;
      if (px > maxX) maxX = px;
      if (py > maxY) maxY = py;
    }

    const pad = Math.max(8, stroke.size);
    ctx.save();
    ctx.strokeStyle = '#007aff';
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 4]);
    ctx.strokeRect(minX - pad, minY - pad, maxX - minX + pad * 2, maxY - minY + pad * 2);
    ctx.setLineDash([]);
    ctx.restore();
  }

  function onSelectDown(e) {
    const pos = getPos(e);
    const idx = findStrokeAt(pos.x, pos.y);

    if (idx === -1) {
      STATE.selectedStrokeIndex = -1;
      redrawDisplay();
      return;
    }

    STATE.selectedStrokeIndex = idx;

    const stroke = STATE.strokes[idx];

    const snapshotPoints = JSON.parse(JSON.stringify(stroke.points));
    const snapshotAnchor = stroke.anchor ? JSON.parse(JSON.stringify(stroke.anchor)) : null;

    const shift = getAnchorShift(stroke);
    if (shift && (shift.dx !== 0 || shift.dy !== 0)) {
      for (const p of stroke.points) {
        p.x += shift.dx;
        p.y += shift.dy;
      }
      stroke.anchor = null;
    }

    STATE.selectDragState = {
      lastX: pos.x,
      lastY: pos.y,
      moved: false,
      snapshotPoints,
      snapshotAnchor,
    };
    drawCanvas.style.cursor = 'grabbing';
    redrawDisplay();
  }

  function onSelectMove(e) {
    if (!STATE.selectDragState || STATE.selectedStrokeIndex < 0) return;
    e.preventDefault();

    const pos = getPos(e);
    const dx = pos.x - STATE.selectDragState.lastX;
    const dy = pos.y - STATE.selectDragState.lastY;

    const stroke = STATE.strokes[STATE.selectedStrokeIndex];
    for (const p of stroke.points) {
      p.x += dx;
      p.y += dy;
    }

    STATE.selectDragState.lastX = pos.x;
    STATE.selectDragState.lastY = pos.y;
    STATE.selectDragState.moved = true;
    redrawDisplay();
  }

  function onSelectUp() {
    if (STATE.selectDragState && STATE.selectedStrokeIndex >= 0) {
      const stroke = STATE.strokes[STATE.selectedStrokeIndex];
      stroke.anchor = computeAnchor(stroke);

      if (STATE.selectDragState.moved) {
        redoHistory.length = 0;
        undoHistory.push({
          type: 'move',
          index: STATE.selectedStrokeIndex,
          oldPoints: STATE.selectDragState.snapshotPoints,
          oldAnchor: STATE.selectDragState.snapshotAnchor,
        });
      }

      saveStrokes();
    }
    STATE.selectDragState = null;
    drawCanvas.style.cursor = 'default';
  }

  function scanForScrollContainer() {
    if (document.documentElement.scrollHeight > window.innerHeight + 5) {
      return null;
    }
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_ELEMENT);
    let best = null;
    let bestArea = 0;
    let node;
    while ((node = walker.nextNode())) {
      if (node.scrollHeight <= node.clientHeight + 5) continue;
      const s = getComputedStyle(node);
      const ov = s.overflowY;
      if (ov !== 'auto' && ov !== 'scroll') continue;
      const rect = node.getBoundingClientRect();
      if (rect.width < window.innerWidth * 0.3 || rect.height < window.innerHeight * 0.3) continue;
      const area = rect.width * rect.height;
      if (area > bestArea) {
        bestArea = area;
        best = node;
      }
    }
    return best;
  }

  document.addEventListener('scroll', (e) => {
    const target = e.target;

    if (target === document || target === document.documentElement) {
      scrollEl = null;
    } else if (target instanceof HTMLElement) {
      const rect = target.getBoundingClientRect();
      if (rect.width > window.innerWidth * 0.3 && rect.height > window.innerHeight * 0.3) {
        scrollEl = target;
      }
    }

    onScroll();
  }, { capture: true, passive: true });

  // ======================== DOM 元素 ========================

  const displayCanvas = document.createElement('canvas');
  displayCanvas.id = 'wa-display-canvas';
  document.documentElement.appendChild(displayCanvas);

  const drawCanvas = document.createElement('canvas');
  drawCanvas.id = 'wa-draw-canvas';
  document.documentElement.appendChild(drawCanvas);

  const displayCtx = displayCanvas.getContext('2d');
  const drawCtx = drawCanvas.getContext('2d');

  const toolbar = document.createElement('div');
  toolbar.id = 'wa-toolbar';
  toolbar.innerHTML = buildToolbarHTML();
  document.documentElement.appendChild(toolbar);

  const textOverlayContainer = document.createElement('div');
  textOverlayContainer.id = 'wa-text-overlays';
  document.documentElement.appendChild(textOverlayContainer);

  const eraserCursor = document.createElement('div');
  eraserCursor.id = 'wa-eraser-cursor';
  document.documentElement.appendChild(eraserCursor);

  const welcomeModal = document.createElement('div');
  welcomeModal.id = 'wa-welcome';
  welcomeModal.innerHTML = buildWelcomeHTML();
  document.documentElement.appendChild(welcomeModal);

  welcomeModal.addEventListener('click', (e) => {
    if (e.target.closest('.wa-welcome-start')) {
      dismissWelcome(true);
    }
  });

  // ======================== 欢迎弹窗 ========================

  function buildWelcomeHTML() {
    const toolRows = TOOL_DEFS.map(buildWelcomeRow).join('');
    const actionRows = ACTION_DEFS.map(buildWelcomeRow).join('');

    return `
      <div class="wa-welcome-card" role="dialog" aria-modal="true" aria-labelledby="wa-welcome-title">
        <div class="wa-welcome-header">
          <div class="wa-welcome-icon-main">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19l7-7 3 3-7 7-3-3z"></path><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path><path d="M2 2l7.586 7.586"></path><circle cx="11" cy="11" r="2"></circle></svg>
          </div>
          <h2 id="wa-welcome-title">欢迎使用 Web Annotator</h2>
          <p class="wa-welcome-lead">轻松在网页上进行批注、高亮和绘图。<br/>在任意页面点击右上角扩展图标即可激活创作。</p>
        </div>
        
        <div class="wa-welcome-content">
          <div class="wa-welcome-columns">
            <div class="wa-welcome-group">
              <h3>绘图工具</h3>
              <div class="wa-welcome-grid">
                ${toolRows}
              </div>
            </div>
            <div class="wa-welcome-group">
              <h3>快捷操作</h3>
              <div class="wa-welcome-grid">
                ${actionRows}
              </div>
            </div>
          </div>
        </div>
        
        <div class="wa-welcome-footer">
          <button class="wa-welcome-start" type="button">开始体验</button>
        </div>
      </div>
    `;
  }

  function buildWelcomeRow(item) {
    return `
      <div class="wa-welcome-row">
        <div class="wa-welcome-icon" aria-hidden="true">${item.icon}</div>
        <div class="wa-welcome-text">
          <div class="wa-welcome-label">${item.label}</div>
          <div class="wa-welcome-desc">${item.help}</div>
        </div>
      </div>
    `;
  }

  // ======================== 工具栏 HTML ========================

  function getCurrentToolIcon() {
    const def = TOOL_DEFS.find(t => t.id === STATE.tool);
    return def ? def.icon : (TOOL_DEFS[1] ? TOOL_DEFS[1].icon : '');
  }

  function buildToolbarHTML() {
    // 紧凑模式圆形切换按钮（始终显示当前工具图标）
    let html = `<div class="wa-compact-icon" id="wa-compact-toggle" data-tip="展开工具栏">
      <div class="wa-compact-tool-icon">${getCurrentToolIcon()}</div>
    </div>`;
    
    // 完整工具栏内容用 wrapper 包裹，紧凑时隐藏
    html += '<div class="wa-tb-sections-wrapper">';
    
    html += '<div class="wa-tb-section wa-tb-tools">';
    for (const t of TOOL_DEFS) {
      html += `<button class="wa-tb-btn" data-tool="${t.id}" data-tip="${t.label}">${t.icon}</button>`;
    }
    html += '</div>';

    html += '<div class="wa-tb-divider"></div>';
    html += '<div class="wa-tb-section wa-tb-colors">';
    for (const c of COLORS) {
      html += `<span class="wa-tb-color" data-color="${c}" style="background:${c}"></span>`;
    }
    html += '</div>';

    html += '<div class="wa-tb-divider"></div>';
    html += '<div class="wa-tb-section wa-tb-sizes">';
    for (const s of SIZES) {
      html += `<span class="wa-tb-size" data-size="${s}"><span style="width:${s}px;height:${s}px"></span></span>`;
    }
    html += '</div>';

    html += '<div class="wa-tb-divider"></div>';
    html += '<div class="wa-tb-section wa-tb-actions">';
    for (const action of ACTION_DEFS) {
      html += `<button class="wa-tb-btn ${action.className}" data-tip="${action.label}">${action.icon}</button>`;
    }
    html += '</div>';

    html += '</div>'; // 关闭 wa-tb-sections-wrapper
    return html;
  }

  // ======================== 画布尺寸 ========================

  function resizeCanvases() {
    const dpr = window.devicePixelRatio || 1;
    const w = window.innerWidth;
    const h = window.innerHeight;

    for (const cvs of [displayCanvas, drawCanvas]) {
      cvs.width = w * dpr;
      cvs.height = h * dpr;
      cvs.style.width = w + 'px';
      cvs.style.height = h + 'px';
    }

    displayCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
    drawCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

    redrawDisplay();
  }

  // ======================== 绘制引擎 ========================

  function renderStroke(ctx, stroke, offsetX, offsetY) {
    if (!stroke.points || stroke.points.length === 0) return;

    const shift = getAnchorShift(stroke);
    const dx = shift ? shift.dx : 0;
    const dy = shift ? shift.dy : 0;

    ctx.save();

    if (stroke.tool === 'eraser') {
      ctx.globalCompositeOperation = 'destination-out';
      ctx.strokeStyle = 'rgba(0,0,0,1)';
      ctx.lineWidth = stroke.size;
    } else if (stroke.tool === 'highlighter') {
      ctx.globalCompositeOperation = 'multiply';
      ctx.strokeStyle = stroke.color;
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = stroke.size * 3;
    } else {
      ctx.strokeStyle = stroke.color;
      ctx.lineWidth = stroke.size;
    }

    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.translate(dx - offsetX, dy - offsetY);

    if (stroke.tool === 'text') {
      drawText(ctx, stroke);
    } else if (stroke.tool === 'rect') {
      drawRect(ctx, stroke);
    } else if (stroke.tool === 'arrow') {
      drawArrow(ctx, stroke);
    } else {
      drawFreehand(ctx, stroke);
    }

    ctx.restore();
  }

  function drawFreehand(ctx, stroke) {
    const pts = stroke.points;
    if (pts.length < 2) {
      ctx.beginPath();
      ctx.arc(pts[0].x, pts[0].y, ctx.lineWidth / 2, 0, Math.PI * 2);
      ctx.fillStyle = ctx.strokeStyle;
      ctx.fill();
      return;
    }
    ctx.beginPath();
    ctx.moveTo(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length - 1; i++) {
      const mx = (pts[i].x + pts[i + 1].x) / 2;
      const my = (pts[i].y + pts[i + 1].y) / 2;
      ctx.quadraticCurveTo(pts[i].x, pts[i].y, mx, my);
    }
    const last = pts[pts.length - 1];
    ctx.lineTo(last.x, last.y);
    ctx.stroke();
  }

  function drawRect(ctx, stroke) {
    if (stroke.points.length < 2) return;
    const p0 = stroke.points[0];
    const p1 = stroke.points[stroke.points.length - 1];
    ctx.beginPath();
    ctx.rect(p0.x, p0.y, p1.x - p0.x, p1.y - p0.y);
    ctx.stroke();
  }

  function drawArrow(ctx, stroke) {
    if (stroke.points.length < 2) return;
    const p0 = stroke.points[0];
    const p1 = stroke.points[stroke.points.length - 1];

    ctx.beginPath();
    ctx.moveTo(p0.x, p0.y);
    ctx.lineTo(p1.x, p1.y);
    ctx.stroke();

    const angle = Math.atan2(p1.y - p0.y, p1.x - p0.x);
    const headLen = Math.max(12, ctx.lineWidth * 4);
    ctx.beginPath();
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(
      p1.x - headLen * Math.cos(angle - Math.PI / 6),
      p1.y - headLen * Math.sin(angle - Math.PI / 6)
    );
    ctx.moveTo(p1.x, p1.y);
    ctx.lineTo(
      p1.x - headLen * Math.cos(angle + Math.PI / 6),
      p1.y - headLen * Math.sin(angle + Math.PI / 6)
    );
    ctx.stroke();
  }

  function drawText(ctx, stroke) {
    if (!stroke.text || stroke.points.length < 2) return;
    const p0 = stroke.points[0];
    const p1 = stroke.points[1];
    const x = Math.min(p0.x, p1.x);
    const y = Math.min(p0.y, p1.y);
    const w = Math.abs(p1.x - p0.x);
    const h = Math.abs(p1.y - p0.y);

    const fontSize = Math.max(12, Math.min(stroke.size * 4, h * 0.8));
    ctx.save();
    ctx.fillStyle = stroke.color;
    ctx.font = `${fontSize}px ${FONT_FAMILY}`;
    ctx.textBaseline = 'top';

    const padding = 6;
    const lines = wrapText(ctx, stroke.text, w - padding * 2);
    const lineHeight = fontSize * 1.3;
    for (let i = 0; i < lines.length; i++) {
      const ly = y + padding + i * lineHeight;
      if (ly + lineHeight > y + h + lineHeight) break;
      ctx.fillText(lines[i], x + padding, ly);
    }
    ctx.restore();
  }

  function wrapText(ctx, text, maxWidth) {
    if (maxWidth <= 0) return [text];
    const result = [];
    const paragraphs = text.split('\n');
    for (const para of paragraphs) {
      if (!para) { result.push(''); continue; }
      let line = '';
      for (const ch of para) {
        const test = line + ch;
        if (ctx.measureText(test).width > maxWidth && line) {
          result.push(line);
          line = ch;
        } else {
          line = test;
        }
      }
      if (line) result.push(line);
    }
    return result;
  }

  function redrawDisplay() {
    const dpr = window.devicePixelRatio || 1;
    displayCtx.clearRect(0, 0, displayCanvas.width / dpr, displayCanvas.height / dpr);
    const scroll = getScroll();
    for (const s of STATE.strokes) {
      renderStroke(displayCtx, s, scroll.x, scroll.y);
    }
    if (STATE.selectedStrokeIndex >= 0 && STATE.selectedStrokeIndex < STATE.strokes.length) {
      drawSelectionBox(displayCtx, STATE.strokes[STATE.selectedStrokeIndex], scroll);
    }
  }

  function redrawDrawing() {
    const dpr = window.devicePixelRatio || 1;
    drawCtx.clearRect(0, 0, drawCanvas.width / dpr, drawCanvas.height / dpr);
    if (!STATE.currentStroke) return;
    const scroll = getScroll();

    if (STATE.currentStroke.tool === 'text' && STATE.currentStroke.points.length >= 2) {
      const p0 = STATE.currentStroke.points[0];
      const p1 = STATE.currentStroke.points[1];
      drawCtx.save();
      drawCtx.strokeStyle = STATE.currentStroke.color;
      drawCtx.lineWidth = 1.5;
      drawCtx.setLineDash([5, 4]);
      drawCtx.strokeRect(
        p0.x - scroll.x, p0.y - scroll.y,
        p1.x - p0.x, p1.y - p0.y
      );
      drawCtx.setLineDash([]);
      drawCtx.restore();
    } else {
      renderStroke(drawCtx, STATE.currentStroke, scroll.x, scroll.y);
    }
  }

  // ======================== 文本选取覆盖层 ========================

  function syncTextOverlays() {
    textOverlayContainer.innerHTML = '';

    if (STATE.active || !STATE.textSelectable) {
      textOverlayContainer.classList.remove('visible');
      return;
    }

    const scroll = getScroll();
    let hasOverlays = false;

    for (const stroke of STATE.strokes) {
      if (stroke.tool !== 'text' || !stroke.text || stroke.points.length < 2) continue;

      const shift = getAnchorShift(stroke);
      const sdx = shift ? shift.dx : 0;
      const sdy = shift ? shift.dy : 0;

      const p0 = stroke.points[0];
      const p1 = stroke.points[1];
      const x = Math.min(p0.x + sdx, p1.x + sdx) - scroll.x;
      const y = Math.min(p0.y + sdy, p1.y + sdy) - scroll.y;
      const w = Math.abs(p1.x - p0.x);
      const h = Math.abs(p1.y - p0.y);
      const fontSize = Math.max(12, Math.min(stroke.size * 4, h * 0.8));

      const div = document.createElement('div');
      div.className = 'wa-text-overlay';
      div.textContent = stroke.text;
      div.style.left = x + 'px';
      div.style.top = y + 'px';
      div.style.width = w + 'px';
      div.style.height = h + 'px';
      div.style.fontSize = fontSize + 'px';
      div.style.padding = '6px';
      div._waStroke = stroke;

      textOverlayContainer.appendChild(div);
      hasOverlays = true;
    }

    textOverlayContainer.classList.toggle('visible', hasOverlays);
  }

  function repositionTextOverlays() {
    if (!textOverlayContainer.classList.contains('visible')) return;

    const scroll = getScroll();
    for (const div of textOverlayContainer.children) {
      const stroke = div._waStroke;
      if (!stroke || stroke.points.length < 2) continue;

      const shift = getAnchorShift(stroke);
      const sdx = shift ? shift.dx : 0;
      const sdy = shift ? shift.dy : 0;

      const p0 = stroke.points[0];
      const p1 = stroke.points[1];
      div.style.left = (Math.min(p0.x + sdx, p1.x + sdx) - scroll.x) + 'px';
      div.style.top = (Math.min(p0.y + sdy, p1.y + sdy) - scroll.y) + 'px';
    }
  }

  // ======================== 滚动 → 重绘 ========================

  let rafId = null;
  function onScroll() {
    if (STATE.strokes.length === 0 && !STATE.currentStroke) return;
    if (rafId) return;
    rafId = requestAnimationFrame(() => {
      rafId = null;
      redrawDisplay();
      if (STATE.currentStroke) redrawDrawing();
      repositionTextOverlays();
    });
  }

  // ======================== 鼠标 / 触摸事件 ========================

  function getPos(e) {
    const ev = e.touches ? e.touches[0] : e;
    const scroll = getScroll();
    return { x: ev.clientX + scroll.x, y: ev.clientY + scroll.y };
  }

  // ======================== 工具栏展开/收起 ========================

  function toggleToolbarExpand(expanded) {
    STATE.expanded = typeof expanded === 'boolean' ? expanded : !STATE.expanded;
    toolbar.classList.toggle('wa-compact', !STATE.expanded);
    
    if (STATE.expanded) {
      // 展开时更新紧凑图标为当前工具
      updateCompactIcon();
    }
  }

  function updateCompactIcon() {
    const iconEl = toolbar.querySelector('.wa-compact-tool-icon');
    if (iconEl) {
      iconEl.innerHTML = getCurrentToolIcon();
    }
  }

  // ======================== 点击外部收起工具栏 ========================

  document.addEventListener('click', (e) => {
    // 如果工具栏展开，且点击不在工具栏内部，则收起
    if (STATE.expanded && !e.target.closest('#wa-toolbar')) {
      toggleToolbarExpand(false);
    }
  });

  function onPointerDown(e) {
    if (!STATE.active) return;
    if (e.target.closest('#wa-toolbar') || e.target.closest('.wa-text-input')) return;

    if (activeTextInput) {
      e.preventDefault();
      commitTextInput();
      return;
    }

    e.preventDefault();

    // 自动收起：开始绘制时如果 autoCompact 开启，收起工具栏
    if (STATE.autoCompact && STATE.expanded) {
      toggleToolbarExpand(false);
    }

    if (STATE.tool === 'select') {
      onSelectDown(e);
      return;
    }

    if (STATE.tool === 'eraser') {
      STATE.erasing = true;
      eraserDirty = false;
      eraserSnapshot = JSON.parse(JSON.stringify(STATE.strokes));
      const pos = getPos(e);
      eraseAtPoint(pos.x, pos.y);
      return;
    }

    STATE.drawing = true;
    const pos = getPos(e);
    STATE.startX = pos.x;
    STATE.startY = pos.y;

    STATE.currentStroke = {
      tool: STATE.tool,
      color: STATE.color,
      size: STATE.size,
      points: [pos],
      text: '',
    };
  }

  function onPointerMove(e) {
    if (STATE.tool === 'eraser' && STATE.active) {
      const ev = e.touches ? e.touches[0] : e;
      updateEraserCursor(ev.clientX, ev.clientY);
      if (STATE.erasing) {
        e.preventDefault();
        const pos = getPos(e);
        eraseAtPoint(pos.x, pos.y);
      }
      return;
    }

    if (STATE.tool === 'select') {
      if (STATE.selectDragState) onSelectMove(e);
      return;
    }

    if (!STATE.drawing || !STATE.currentStroke) return;
    e.preventDefault();

    const pos = getPos(e);

    if (STATE.tool === 'rect' || STATE.tool === 'arrow' || STATE.tool === 'text') {
      STATE.currentStroke.points = [
        { x: STATE.startX, y: STATE.startY },
        pos,
      ];
    } else {
      STATE.currentStroke.points.push(pos);
    }

    redrawDrawing();
  }

  function onPointerUp() {
    if (STATE.tool === 'select') {
      onSelectUp();
      return;
    }

    if (STATE.tool === 'eraser') {
      if (STATE.erasing && eraserSnapshot && eraserDirty) {
        redoHistory.length = 0;
        undoHistory.push({ type: 'erase-session', snapshot: eraserSnapshot });
        saveStrokes();
      }
      STATE.erasing = false;
      eraserSnapshot = null;
      eraserDirty = false;
      return;
    }

    if (!STATE.drawing) return;
    STATE.drawing = false;

    if (!STATE.currentStroke || STATE.currentStroke.points.length === 0) {
      STATE.currentStroke = null;
      return;
    }

    if (STATE.currentStroke.tool === 'text') {
      showTextInput(STATE.currentStroke);
      return;
    }

    STATE.currentStroke.anchor = computeAnchor(STATE.currentStroke);
    redoHistory.length = 0;
    undoHistory.push({ type: 'draw' });
    STATE.strokes.push(STATE.currentStroke);
    saveStrokes();

    STATE.currentStroke = null;
    const dpr = window.devicePixelRatio || 1;
    drawCtx.clearRect(0, 0, drawCanvas.width / dpr, drawCanvas.height / dpr);
    redrawDisplay();
  }

  // ======================== 文本输入弹窗 ========================

  let activeTextInput = null;

  function showTextInput(stroke) {
    removeTextInput();

    if (stroke.points.length < 2) { STATE.currentStroke = null; return; }
    const p0 = stroke.points[0];
    const p1 = stroke.points[1];
    const scroll = getScroll();
    const left = Math.min(p0.x, p1.x) - scroll.x;
    const top = Math.min(p0.y, p1.y) - scroll.y;
    const width = Math.abs(p1.x - p0.x);
    const height = Math.abs(p1.y - p0.y);

    if (width < 20 || height < 16) { STATE.currentStroke = null; return; }

    const container = document.createElement('div');
    container.className = 'wa-text-input';
    container.style.left = left + 'px';
    container.style.top = top + 'px';
    container.style.width = width + 'px';
    container.style.height = height + 'px';

    const textarea = document.createElement('textarea');
    textarea.style.color = stroke.color;
    textarea.style.fontSize = Math.max(12, Math.min(stroke.size * 4, height * 0.8)) + 'px';
    textarea.placeholder = '输入文本…';
    container.appendChild(textarea);

    document.documentElement.appendChild(container);
    activeTextInput = { container, textarea, stroke };
    textarea.focus();

    textarea.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        commitTextInput();
      } else if (e.key === 'Escape') {
        removeTextInput();
      }
    });
  }

  function shrinkTextBox(stroke) {
    if (!stroke.text || stroke.points.length < 2) return;

    const p0 = stroke.points[0];
    const p1 = stroke.points[1];
    const x = Math.min(p0.x, p1.x);
    const y = Math.min(p0.y, p1.y);
    const w = Math.abs(p1.x - p0.x);
    const h = Math.abs(p1.y - p0.y);

    const padding = 6;
    const fontSize = Math.max(12, Math.min(stroke.size * 4, h * 0.8));
    const lineHeight = fontSize * 1.3;
    const fontStr = `${fontSize}px ${FONT_FAMILY}`;

    displayCtx.save();
    displayCtx.font = fontStr;

    const lines = wrapText(displayCtx, stroke.text, w - padding * 2);

    let maxLineW = 0;
    for (const ln of lines) {
      maxLineW = Math.max(maxLineW, displayCtx.measureText(ln).width);
    }
    displayCtx.restore();

    const newW = Math.max(maxLineW + padding * 2 + 2, 20);
    const newH = Math.max(lines.length * lineHeight + padding * 2, fontSize / 0.8);

    stroke.points[0] = { x, y };
    stroke.points[1] = { x: x + newW, y: y + newH };
  }

  function commitTextInput() {
    if (!activeTextInput) return;
    const { textarea, stroke } = activeTextInput;
    const text = textarea.value.trim();
    if (text) {
      stroke.text = text;
      shrinkTextBox(stroke);
      stroke.anchor = computeAnchor(stroke);
      redoHistory.length = 0;
      undoHistory.push({ type: 'draw' });
      STATE.strokes.push(stroke);
      saveStrokes();
    }
    STATE.currentStroke = null;
    const dpr = window.devicePixelRatio || 1;
    drawCtx.clearRect(0, 0, drawCanvas.width / dpr, drawCanvas.height / dpr);
    removeTextInput();
    redrawDisplay();
  }

  function removeTextInput() {
    if (activeTextInput) {
      activeTextInput.container.remove();
      activeTextInput = null;
    }
    STATE.currentStroke = null;
    const dpr = window.devicePixelRatio || 1;
    drawCtx.clearRect(0, 0, drawCanvas.width / dpr, drawCanvas.height / dpr);
  }

  drawCanvas.addEventListener('mousedown', onPointerDown);
  drawCanvas.addEventListener('mousemove', onPointerMove);
  drawCanvas.addEventListener('mouseup', onPointerUp);
  drawCanvas.addEventListener('mouseleave', () => {
    onPointerUp();
    eraserCursor.style.display = 'none';
  });
  drawCanvas.addEventListener('mouseenter', () => {
    if (STATE.tool === 'eraser' && STATE.active) {
      eraserCursor.style.display = 'block';
    }
  });
  drawCanvas.addEventListener('touchstart', onPointerDown, { passive: false });
  drawCanvas.addEventListener('touchmove', onPointerMove, { passive: false });
  drawCanvas.addEventListener('touchend', onPointerUp);

  let resizeRafId = null;
  window.addEventListener('resize', () => {
    if (STATE.strokes.length === 0 && !STATE.active) return;
    if (resizeRafId) return;
    resizeRafId = requestAnimationFrame(() => {
      resizeRafId = null;
      resizeCanvases();
      syncTextOverlays();
    });
  });

  drawCanvas.addEventListener('wheel', (e) => {
    e.preventDefault();
    const target = scrollEl || document.documentElement;
    target.scrollBy({ left: e.deltaX, top: e.deltaY });
  }, { passive: false });

  // ======================== 工具栏交互 ========================

  toolbar.addEventListener('click', (e) => {
    if (activeTextInput) commitTextInput();

    // 紧凑模式点击：展开工具栏
    const compactToggle = e.target.closest('#wa-compact-toggle');
    if (compactToggle) {
      e.stopPropagation();
      toggleToolbarExpand(true);
      return;
    }

    const btn = e.target.closest('[data-tool]');
    if (btn) {
      STATE.tool = btn.dataset.tool;
      STATE.selectedStrokeIndex = -1;
      STATE.selectDragState = null;
      updateToolbarState();
      savePrefs();
      return;
    }

    const colorEl = e.target.closest('[data-color]');
    if (colorEl) {
      STATE.color = colorEl.dataset.color;
      updateToolbarState();
      savePrefs();
      return;
    }

    const sizeEl = e.target.closest('[data-size]');
    if (sizeEl) {
      STATE.size = parseInt(sizeEl.dataset.size);
      updateToolbarState();
      savePrefs();
      return;
    }

    if (e.target.closest('.wa-tb-text-select')) {
      STATE.textSelectable = !STATE.textSelectable;
      updateToolbarState();
      savePrefs();
      return;
    }

    if (e.target.closest('.wa-tb-undo')) {
      undo();
      return;
    }

    if (e.target.closest('.wa-tb-redo')) {
      redo();
      return;
    }

    if (e.target.closest('.wa-tb-clear')) {
      clearAll();
      return;
    }

    if (e.target.closest('.wa-tb-export')) {
      exportAnnotations();
      return;
    }

    if (e.target.closest('.wa-tb-import')) {
      importAnnotations();
      return;
    }

    if (e.target.closest('.wa-tb-close')) {
      toggleDrawingMode(false);
    }
  });

  toolbar.addEventListener('mousedown', e => e.stopPropagation());

  // ======================== 自定义 Tooltip ========================
  const tooltip = document.createElement('div');
  tooltip.id = 'wa-tooltip';
  document.documentElement.appendChild(tooltip);

  let tipTimer = null;

  toolbar.addEventListener('mouseover', (e) => {
    const target = e.target.closest('[data-tip]');
    if (!target) return;
    clearTimeout(tipTimer);
    tipTimer = setTimeout(() => {
      tooltip.textContent = target.dataset.tip;
      const rect = target.getBoundingClientRect();
      tooltip.style.left = (rect.left + rect.width / 2 - tooltip.offsetWidth / 2) + 'px';
      tooltip.style.top = (rect.bottom + 6) + 'px';
      tooltip.classList.add('visible');
    }, 300);
  });

  toolbar.addEventListener('mouseout', (e) => {
    const target = e.target.closest('[data-tip]');
    if (!target) return;
    clearTimeout(tipTimer);
    tooltip.classList.remove('visible');
  });

  toolbar.addEventListener('click', () => {
    clearTimeout(tipTimer);
    tooltip.classList.remove('visible');
  });

  let tbDragging = false, tbOffX = 0, tbOffY = 0;
  toolbar.addEventListener('mousedown', (e) => {
    if (e.target.closest('button, .wa-tb-color, .wa-tb-size')) return;
    tbDragging = true;
    const tbRect = toolbar.getBoundingClientRect();
    tbOffX = e.clientX - tbRect.left;
    tbOffY = e.clientY - tbRect.top;
    e.preventDefault();
  });
  document.addEventListener('mousemove', (e) => {
    if (!tbDragging) return;
    toolbar.style.left = (e.clientX - tbOffX) + 'px';
    toolbar.style.top = (e.clientY - tbOffY) + 'px';
    toolbar.style.right = 'auto';
    toolbar.style.bottom = 'auto';
  });
  document.addEventListener('mouseup', () => { tbDragging = false; });

  function updateToolbarState() {
    toolbar.querySelectorAll('[data-tool]').forEach(el => {
      el.classList.toggle('active', el.dataset.tool === STATE.tool);
    });
    toolbar.querySelectorAll('[data-color]').forEach(el => {
      el.classList.toggle('active', el.dataset.color === STATE.color);
    });
    toolbar.querySelectorAll('[data-size]').forEach(el => {
      el.classList.toggle('active', parseInt(el.dataset.size) === STATE.size);
    });
    drawCanvas.style.cursor = STATE.tool === 'select' ? 'default' : STATE.tool === 'eraser' ? 'none' : 'crosshair';
    eraserCursor.style.display = (STATE.tool === 'eraser' && STATE.active) ? 'block' : 'none';

    const tsBtn = toolbar.querySelector('.wa-tb-text-select');
    if (tsBtn) tsBtn.classList.toggle('active', STATE.textSelectable);
    
    // 更新紧凑模式下的当前工具图标
    updateCompactIcon();
  }

  // ======================== 操作 ========================

  function undo() {
    if (undoHistory.length === 0) return;
    STATE.selectedStrokeIndex = -1;
    const action = undoHistory.pop();

    if (action.type === 'draw') {
      const stroke = STATE.strokes.pop();
      redoHistory.push({ type: 'draw', stroke });
    } else if (action.type === 'erase-session') {
      const current = JSON.parse(JSON.stringify(STATE.strokes));
      STATE.strokes = JSON.parse(JSON.stringify(action.snapshot));
      redoHistory.push({ type: 'erase-session', snapshot: current });
    } else if (action.type === 'move') {
      const stroke = STATE.strokes[action.index];
      const curPoints = JSON.parse(JSON.stringify(stroke.points));
      const curAnchor = stroke.anchor ? JSON.parse(JSON.stringify(stroke.anchor)) : null;
      stroke.points = action.oldPoints;
      stroke.anchor = action.oldAnchor;
      redoHistory.push({ type: 'move', index: action.index, oldPoints: curPoints, oldAnchor: curAnchor });
    }

    redrawDisplay();
    saveStrokes();
  }

  function redo() {
    if (redoHistory.length === 0) return;
    STATE.selectedStrokeIndex = -1;
    const action = redoHistory.pop();

    if (action.type === 'draw') {
      STATE.strokes.push(action.stroke);
      undoHistory.push({ type: 'draw' });
    } else if (action.type === 'erase-session') {
      const current = JSON.parse(JSON.stringify(STATE.strokes));
      STATE.strokes = JSON.parse(JSON.stringify(action.snapshot));
      undoHistory.push({ type: 'erase-session', snapshot: current });
    } else if (action.type === 'move') {
      const stroke = STATE.strokes[action.index];
      const curPoints = JSON.parse(JSON.stringify(stroke.points));
      const curAnchor = stroke.anchor ? JSON.parse(JSON.stringify(stroke.anchor)) : null;
      stroke.points = action.oldPoints;
      stroke.anchor = action.oldAnchor;
      undoHistory.push({ type: 'move', index: action.index, oldPoints: curPoints, oldAnchor: curAnchor });
    }

    redrawDisplay();
    saveStrokes();
  }

  function clearAll() {
    if (STATE.strokes.length === 0) return;
    STATE.selectedStrokeIndex = -1;
    undoHistory.length = 0;
    redoHistory.length = 0;
    STATE.strokes = [];
    redrawDisplay();
    saveStrokes();
  }

  function exportAnnotations() {
    const allData = {};

    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('wa_draw_')) {
        try {
          const val = JSON.parse(localStorage.getItem(key));
          if (Array.isArray(val) && val.length > 0) {
            allData[key] = val;
          }
        } catch {}
      }
    }

    if (STATE.strokes.length > 0) {
      allData[pageKey()] = STATE.strokes;
    }

    if (Object.keys(allData).length === 0) {
      alert('没有可导出的标注数据');
      return;
    }

    const json = JSON.stringify(allData, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `web-annotations-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function importAnnotations() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.style.display = 'none';
    document.body.appendChild(input);

    input.addEventListener('change', () => {
      const file = input.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          if (typeof data !== 'object' || data === null) {
            alert('文件格式不正确');
            return;
          }

          let count = 0;
          for (const [key, strokes] of Object.entries(data)) {
            if (!key.startsWith('wa_draw_') || !Array.isArray(strokes)) continue;
            try { localStorage.setItem(key, JSON.stringify(strokes)); } catch {}
            try { chrome.storage.local.set({ [key]: strokes }); } catch {}
            count += strokes.length;
          }

          const currentKey = pageKey();
          if (data[currentKey] && Array.isArray(data[currentKey])) {
            STATE.strokes = data[currentKey];
            undoHistory.length = 0;
            redoHistory.length = 0;
            resizeCanvases();
            displayCanvas.classList.add('visible');
          }

          alert(`导入成功：${Object.keys(data).length} 个页面，共 ${count} 条标注`);
        } catch {
          alert('导入失败：文件解析出错');
        }
      };
      reader.readAsText(file);
      input.remove();
    });

    input.click();
  }

  // ======================== 切换绘画模式与欢迎窗口 ========================

  function toggleDrawingMode(forceState) {
    STATE.active = typeof forceState === 'boolean' ? forceState : !STATE.active;

    drawCanvas.classList.toggle('active', STATE.active);
    toolbar.classList.toggle('active', STATE.active);
    displayCanvas.classList.toggle('visible', STATE.active || STATE.strokes.length > 0);

    if (STATE.active) {
      resizeCanvases();
      updateToolbarState();
      // 激活时默认进入紧凑模式
      if (!toolbar.classList.contains('wa-compact')) {
        toolbar.classList.add('wa-compact');
        STATE.expanded = false;
      }
    } else {
      STATE.drawing = false;
      STATE.currentStroke = null;
      STATE.selectedStrokeIndex = -1;
      STATE.selectDragState = null;
      STATE.erasing = false;
      eraserCursor.style.display = 'none';
    }

    syncTextOverlays();
  }

  function showWelcome() {
    welcomeModal.classList.add('active');
    // 延迟 400ms，在卡片刚结束弹出的同时触发礼花效果
    setTimeout(fireConfetti, 400); 
  }

  // 生成并喷发礼花
  function fireConfetti() {
    const card = welcomeModal.querySelector('.wa-welcome-card');
    if (!card) return;

    const colors = ['#007aff', '#34c759', '#ffcc00', '#ff3b30', '#af52de', '#ff9500'];
    const container = document.createElement('div');
    container.className = 'wa-confetti-container';
    card.appendChild(container);

    // 左右两边各发 30 个粒子
    for (let i = 0; i < 60; i++) {
      const isLeft = i < 30;
      const wrapper = document.createElement('div');
      wrapper.className = 'wa-confetti-wrapper';
      
      const piece = document.createElement('div');
      piece.className = 'wa-confetti-piece';
      
      piece.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      // 增加随机形状（圆形或矩形）和大小，使效果更丰富
      if (Math.random() > 0.5) piece.style.borderRadius = '50%';
      if (Math.random() > 0.7) {
        piece.style.width = '6px';
        piece.style.height = '10px';
      }

      // 起点设置在左右上角附近，往下移一点
      wrapper.style.left = isLeft ? '30px' : 'calc(100% - 30px)';
      wrapper.style.top = '100px';

      // 随机爆炸向量参数（CSS Variables）
      const tx = (Math.random() * 250 + 50) * (isLeft ? 1 : -1);
      const ty = Math.random() * -150 - 50;
      const rot = Math.random() * 720 - 360;
      const scale = Math.random() * 0.6 + 0.4;

      wrapper.style.setProperty('--tx', `${tx}px`);
      piece.style.setProperty('--ty', `${ty}px`);
      piece.style.setProperty('--rot', `${rot}deg`);
      piece.style.setProperty('--scale', scale);

      wrapper.appendChild(piece);
      container.appendChild(wrapper);
    }

    // 动画结束后自动清理 DOM
    setTimeout(() => {
      if (container.parentNode) container.remove();
    }, 2500);
  }

  function dismissWelcome(startDrawing) {
    if (!welcomeModal.classList.contains('active')) return;

    markWelcomeSeen();
    welcomeModal.classList.remove('active');

    if (startDrawing) {
      toggleDrawingMode(true);
    }
  }

  async function handleToggleRequest() {
    if (welcomeModal.classList.contains('active')) return;

    if (await shouldShowWelcome()) {
      showWelcome();
      return;
    }

    toggleDrawingMode();
  }

  // ======================== 消息监听 ========================

  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === 'wa-toggle') {
      handleToggleRequest();
    }
  });

  // ======================== 初始化 ========================

  function tryDetectAndRedraw(retries) {
    if (retries <= 0 || STATE.strokes.length === 0) return;
    setTimeout(() => {
      const found = scanForScrollContainer();
      if (found) {
        scrollEl = found;
        redrawDisplay();
      } else if (retries > 1) {
        tryDetectAndRedraw(retries - 1);
      }
    }, 500);
  }

  async function init() {
    const prefs = await loadPrefs();
    if (prefs) {
      if (prefs.tool) STATE.tool = prefs.tool;
      if (prefs.color) STATE.color = prefs.color;
      if (prefs.size) STATE.size = prefs.size;
      if (typeof prefs.textSelectable === 'boolean') STATE.textSelectable = prefs.textSelectable;
      if (typeof prefs.autoCompact === 'boolean') STATE.autoCompact = prefs.autoCompact;
    }

    const strokes = await loadStrokes();
    if (strokes.length > 0) {
      STATE.strokes = strokes;
      resizeCanvases();
      displayCanvas.classList.add('visible');

      const found = scanForScrollContainer();
      if (found) {
        scrollEl = found;
        redrawDisplay();
      } else {
        tryDetectAndRedraw(6);
      }

      setTimeout(() => {
        let changed = false;
        for (const s of STATE.strokes) {
          if (!s.anchor) {
            s.anchor = computeAnchor(s);
            if (s.anchor) changed = true;
          }
        }
        if (changed) saveStrokes();
      }, 1500);

      syncTextOverlays();
    }
    
    // 默认进入紧凑模式（如果已激活则应用）
    if (STATE.active) {
      toolbar.classList.add('wa-compact');
      STATE.expanded = false;
    }
  }

  init();
})();