const WELCOME_PENDING_KEY = 'wa_welcome_pending';

chrome.runtime.onInstalled.addListener(({ reason }) => {
  if (reason === 'install') {
    chrome.storage.local.set({ [WELCOME_PENDING_KEY]: true });
  }
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || tab.url?.startsWith('chrome') || tab.url?.startsWith('edge')) return;

  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'wa-toggle' });
  } catch {
    // Content script not yet injected, inject it first
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      files: ['content.js'],
    });
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id },
      files: ['content.css'],
    });
    await chrome.tabs.sendMessage(tab.id, { type: 'wa-toggle' });
  }
});
