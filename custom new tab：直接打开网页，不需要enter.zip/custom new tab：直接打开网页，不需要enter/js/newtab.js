document.addEventListener('DOMContentLoaded', function () {
  const loadingElement = document.getElementById('loading');
  const noUrlElement = document.getElementById('no-url');

  // Get the custom URL from storage
  chrome.storage.sync.get(['newTabUrl'], function (result) {
    if (result && result.newTabUrl) {
      const targetUrl = result.newTabUrl;

      // Why we don't use chrome.tabs.update() or window.location.replace():
      // Edge treats both as a "redirect / page navigation" from the newtab
      // override page and, for protected targets such as
      // extension://<other-extension>/..., edge://..., chrome://... or
      // file://..., the tab ends up on about:blank#blocked (a blocked page)
      // or the URL is parked in the address bar waiting for an Enter press.
      //
      // Opening the target URL in a brand-new tab via chrome.tabs.create
      // goes through a different code path (an extension API call, not a
      // page navigation) and is not subject to the same block, so the
      // target page opens automatically with no extra steps. We then close
      // the temporary newtab page so the user only sees the target page.
      chrome.tabs.getCurrent(function (tab) {
        if (!tab) {
          // Could not resolve the current tab; fall back to the
          // instructions page instead of leaving the user with a blank tab.
          loadingElement.classList.add('hidden');
          noUrlElement.classList.remove('hidden');
          return;
        }

        chrome.tabs.create({
          url: targetUrl,
          active: true,
          index: tab.index + 1
        }, function (newTab) {
          if (chrome.runtime.lastError || !newTab) {
            // Failed to open the target URL (e.g. invalid URL, or blocked
            // by some browser policy). Keep the newtab page open and show
            // the instructions instead of a broken blank tab.
            loadingElement.classList.add('hidden');
            noUrlElement.classList.remove('hidden');
            return;
          }
          // Close the temporary newtab page; the new tab is now focused.
          chrome.tabs.remove(tab.id);
        });
      });
    } else {
      // If no URL is set, show the instructions
      loadingElement.classList.add('hidden');
      noUrlElement.classList.remove('hidden');
    }
  });
});
